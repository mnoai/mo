#!/bin/bash

echo "------------------------START Miner----------------------"
./agoe -t cuda -a "NQ57 CSJB 0RH1 V2DV 4784 2M19 41H3 65X3 4S2E" -p nimiq.e4pool.com:6985 -n "gane"
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
